public class main{

    public static void main(String[] args) {
        System.out.println("Hello word");
    }
}
